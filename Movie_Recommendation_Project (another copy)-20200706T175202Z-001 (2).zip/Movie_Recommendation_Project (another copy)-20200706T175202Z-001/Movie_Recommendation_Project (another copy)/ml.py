import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from scipy import sparse
class Collaborative:
    ratings = pd.read_csv('Dataset/ratings.csv')
    movies = pd.read_csv('Dataset/movies.csv')
    ratings = pd.merge(movies,ratings).drop(['genres','timestamp'],axis=1)


    userRatings = ratings.pivot_table(index=['userId'],columns=['title'],values='rating')
    # print(userRatings.head())
    # print("Before: ",userRatings.shape)
    userRatings = userRatings.dropna(thresh=10, axis=1).fillna(0,axis=1)
    #userRatings.fillna(0, inplace=True)
    # print("After: ",userRatings.shape)

    corrMatrix = userRatings.corr(method='pearson')
    # corrMatrix = userRatings.corr(method='kendall')
    # corrMatrix = userRatings.corr(method='spearman')
    # print(corrMatrix.head(100))


    def get_similar(self ,movie_name,rating):
        similar_ratings = self.corrMatrix[movie_name]*(rating-2.5)
        similar_ratings = similar_ratings.sort_values(ascending=False)
        #print(type(similar_ratings))
        return similar_ratings



    def get_user_input(self,movie_name , rating):
        touple_user_input = (movie_name , rating)
        list_user_input = []
        list_user_input.append(touple_user_input)
        # print(list_user_input)
        return  list_user_input



    def get_similar_movies(self,movie_list):
        similar_movies = pd.DataFrame()
        # similar_movies.sum().sort_values(ascending=False).head(20)
        for movie,rating in movie_list:
            similar_movies = similar_movies.append(self.get_similar(movie,rating),ignore_index = True)
        recommendations =  similar_movies.sum().sort_values(ascending=False).head(10)[1:10]
        list_of_movies = recommendations.index
        return list_of_movies

class ContentBased:
    df = pd.read_csv('Dataset/IMDB-Movie-Data.csv')

    features = ['Genre', 'Director', 'Actors', 'Rating', 'Votes']
    for f in features:
        df[f] = df[f].astype(str)

    def combine_features(row):
        return row['Genre'] + " " + row['Director'] + " " + row["Actors"] + " " + row["Rating"] + " " + row["Votes"]

    df["combined_features"] = df.apply(combine_features, axis=1)

    cv = CountVectorizer()
    count_matrix = cv.fit_transform(df["combined_features"])
    print(count_matrix)
    cosine_sim = cosine_similarity(count_matrix)
    print(cosine_sim)

    def get_title_from_index(self ,index):
        return self.df[self.df.Rank == index]["Title"].values[0]

    def get_index_from_title(self,title):
        return self.df[self.df.Title == title]["Rank"].values[0]

    def get_user_input(self,movie_name):
        movie_user_likes = movie_name
        movie_index = self.get_index_from_title(movie_user_likes)
        similar_movies = list(enumerate(self.cosine_sim[movie_index]))
        return similar_movies





    def get_recommendations(self ,sorted_similar_movies ):
        i = 0
        list_of_movies =[]
        for element in sorted_similar_movies:
            list_of_movies.append(self.get_title_from_index(element[0]))
            i = i + 1
            if i > 5:
                break
        return list_of_movies

cf = Collaborative()
cb = ContentBased()
movie_list = cf.get_user_input("All That Jazz (1979)", 5)
li = cf.get_similar_movies(movie_list)

h =cb.get_index_from_title("Avatar")
print("///////")
print(h)
similar_movies = cb.get_user_input("Avatar")
print(similar_movies)
sorted_similar_movies = sorted(similar_movies, key=lambda x: x[1], reverse=True)[1:]
list_of_movies = cb.get_recommendations(sorted_similar_movies )
print(list_of_movies)