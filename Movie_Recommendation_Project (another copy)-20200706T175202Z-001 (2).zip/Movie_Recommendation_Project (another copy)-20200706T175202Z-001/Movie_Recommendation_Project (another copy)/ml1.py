import numpy as np
import pandas as pd


# load the data
def load_and_clean_data():
    df = pd.read_csv(
        'Dataset/IMDB-Movie-Data (copy).csv')
    # print(df)

    # In[17]:

    x = df.iloc[:, 0:25].values
    y = df.iloc[:, 25].values
    # print(x)

    # In[18]:

    from sklearn.preprocessing import LabelEncoder
    encoder = LabelEncoder()

    x1 = [0, 22, 23, 24]
    for index in x1:
        x[:, index] = encoder.fit_transform(x[:, index])

    # In[28]:

    from sklearn.model_selection import train_test_split
    return train_test_split(x, y, test_size=0.2, random_state=5730)
#5730

def model_logistic_regression(x_train, y_train):
    from sklearn.linear_model import LogisticRegression
    classifier = LogisticRegression()
    return classifier.fit(x_train, y_train)
#
#
def model_nb(x_train, y_train):
    from sklearn.naive_bayes import GaussianNB
    classifier = GaussianNB()
    return classifier.fit(x_train, y_train)
#
#
def model_dt(x_train, y_train):
    from sklearn.tree import DecisionTreeClassifier
    classifier = DecisionTreeClassifier()
    return classifier.fit(x_train, y_train)


def model_rf(x_train, y_train):
    from sklearn.ensemble import RandomForestClassifier
    classifier = RandomForestClassifier()
    return classifier.fit(x_train, y_train)

def model_svm(x_train, y_train):
    from sklearn.svm import SVC
    classifier = SVC()
    return classifier.fit(x_train, y_train)

# def model_xgboost(x_train , y_train):
#     from xgboost import XGBClassifier
#     classifier = XGBClassifier()
#     return classifier.fit(x_train, y_train)

def cross_validate(algorithm, classifier, x_test, y_test):
    predictions = classifier.predict(x_test)
    from sklearn.metrics import confusion_matrix
    cm = confusion_matrix(y_test, predictions)
    accuracy = (cm[0][0] + cm[1][1]) / (cm[0][0] + cm[0][1] + cm[1][0] + cm[1][1])
    # print(f"{algorithm} has {accuracy * 100}%")
    return accuracy


x_train, x_test, y_train, y_test = load_and_clean_data()
# print(len(x_test[0]))

classifier_glm = model_logistic_regression(x_train, y_train)
glm_accuracy = cross_validate('Logistic Regression', classifier_glm, x_test, y_test)

classifier_nb = model_nb(x_train, y_train)
# predict = classifier_nb.predict()
# print(predict)
nb_accuracy = cross_validate('Naive Bayes', classifier_nb, x_test, y_test)

classifier_dt = model_dt(x_train, y_train)
dt_accuracy = cross_validate('Decision tree', classifier_dt, x_test, y_test)
#
classifier_rf = model_rf(x_train, y_train)

rf_accuracy = cross_validate('Random Forest', classifier_rf, x_test, y_test)

# print(predict)
print(rf_accuracy)

classifier_svm = model_svm(x_train , y_train)
svm_accuracy = cross_validate('SVM' , classifier_svm ,x_test , y_test)
#
# xgboost_classifier = model_xgboost(x_train,y_train)
# xgboost_accuracy = cross_validate('xgBoost',xgboost_classifier,x_test , y_test)
# print(xgboost_accuracy)