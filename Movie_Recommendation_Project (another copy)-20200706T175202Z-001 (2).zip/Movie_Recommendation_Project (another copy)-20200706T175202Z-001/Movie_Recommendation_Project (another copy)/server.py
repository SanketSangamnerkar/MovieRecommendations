import pandas as pd
from flask import Flask, render_template, request
from ml import ContentBased,Collaborative
import ml1

app = Flask(__name__)

df1 = pd.read_csv('Dataset/movies.csv')
name1 = df1.iloc[:, 1].values

df2 = pd.read_csv('Dataset/IMDB-Movie-Data.csv')
name2 = df2.iloc[:,1].values

@app.route('/')
def MyWelcome():
    return render_template('MyWelcome.html')

@app.route('/MyWelcome')
def MyWelcome2():
    return render_template('MyWelcome.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/aboutsp')
def aboutsp():
    return render_template('aboutsp.html')


@app.route('/MyWelcome')
def MyWelcome1():
    return render_template('MyWelcome.html')

@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/predict')
def predict():
    return render_template('predict.html')


@app.route('/analysis')
def analysis():
    return render_template('analysis.html')


@app.route('/', methods=["GET" , "POST"])
def home1():
    page = int(request.form['b'])

    if page == 0 :
        return  render_template('recommendationHome.html')
    elif page ==  1 :
        return  render_template('predict.html')



@app.route('/recommendationHome')
def rechome():
    return render_template('recommendationHome.html')

@app.route('/rec' , methods=["GET" , "POST"])
def rechome1():
    method = int(request.form['a'])
    if method == 0 :
        return render_template('index2.html' , list= name2)
    elif method == 1 :
        return render_template('index.html' , list=name1)





@app.route('/index2',methods=["GET" , "POST"])
def root1():
    if request.method == 'GET':
        return render_template('index.html')


    elif request.method == 'POST':
        movie_name = request.form['movie_title']
        cb = ContentBased()
        similar_movies = cb.get_user_input(movie_name)
        sorted_similar_movies = sorted(similar_movies, key=lambda x: x[1], reverse=True)[1:]
        result = cb.get_recommendations(sorted_similar_movies)
    return render_template('result.html', list=result)


@app.route('/index', methods=["GET", "POST"])
def root2():
    if request.method == 'GET':
        return render_template('index.html')

        # print(request.method)
    elif request.method == 'POST':

        movie_name = request.form['movie_title']
        stars = int(request.form['stars'])
        cf = Collaborative()
        movie_list = cf.get_user_input(movie_name, stars)
        result = cf.get_similar_movies(movie_list)
    return render_template('result.html', list=result)



@app.route('/predict',methods=["GET" , "POST"])
def Prediction_root():
    if request.method == 'GET' :
        return render_template('template.html')

        print(request.method)
    elif request.method == 'POST':
        # print(request.method)

        director = int(request.form['director'])
        actor1 = int(request.form['actor1'])
        actor2 = int(request.form['actor2'])
        actor3 = int(request.form['actor3'])
        runtime = int(request.form['run'])
        algorithm = int(request.form['algorithm'])

        allGenre = {"Action" : 0 , "Adventure" : 0 , "Aniimation" : 0 , "Biography" : 0 , "Comedy" : 0 , "Crime" : 0 , "Drama" : 0 , "Family" : 0 ,"Fantasy" : 0 ,"History" : 0 ,"Horror" : 0 ,"Music" : 0 , "Musical" : 0 , "Mystery" : 0 ,"Romance" : 0 ,"SciFi" : 0 ,"Sport" : 0 ,"Thriller" : 0 , "War" : 0 ,"Western" : 0,}
        genre = request.form.getlist('a')
        # print(genre)

        for val in genre:
            allGenre[val]=1
        # print(allGenre)

        iallGenre=[]

        for val1 in allGenre :
             iallGenre.append(allGenre[val1])

        cnt = 0
        for c in iallGenre:
            cnt = cnt+c
        # print("---------------")
        # print(cnt)


        val = [director,runtime ,iallGenre[0],	iallGenre[1],iallGenre[2]	,iallGenre[3]	,iallGenre[4]	,iallGenre[5]	,iallGenre[6]	,iallGenre[7]	,iallGenre[8]	,iallGenre[9],iallGenre[10],iallGenre[11],iallGenre[12],iallGenre[13],iallGenre[14],iallGenre[15],iallGenre[16],iallGenre[17],iallGenre[18],iallGenre[19],actor1 , actor2 ,actor3  ]
        # print("======val========")
        # print(val)
        algorithm_name = ''
        accuracy = 0

        if runtime <30 :
           return render_template('error.html',msg = "Wrong value for run time must be 30 or above  and less than 180" )
        elif runtime >190:
            return render_template('error.html',msg ="Wrong value for run time must be 30 or above  and less than 180")
        elif cnt == 0 :
            return render_template('error.html',msg="Pleas Select atleast one genre")
        else:


            if algorithm == 4:
                predict = ml1.classifier_nb.predict([val])
                algorithm_name = 'Naive Bayes'
                accuracy = ml1.nb_accuracy

                # print(predict[0])
                # print(accuracy)

            elif algorithm == 1:
                predict = ml1.classifier_glm.predict([val])
                algorithm_name = 'Logistic Regression'
                accuracy = ml1.glm_accuracy

                # print(predict[0])
                # print(accuracy)

            elif algorithm == 3:
                predict = ml1.classifier_svm.predict([val])
                algorithm_name = 'SVM'
                accuracy = ml1.svm_accuracy

                # print(predict[0])
                # print(accuracy)

            elif algorithm == 0:
                predict = ml1.classifier_rf.predict([val])
                algorithm_name = 'Random Forest'
                accuracy = ml1.rf_accuracy

                # print(predict[0])
                # print(accuracy)

            elif algorithm == 2:
                predict = ml1.classifier_dt.predict([val])
                algorithm_name = 'Decision Tree'
                accuracy = ml1.dt_accuracy

            # print(predict[0])
            # print(accuracy)

        # print(prediction[0])

    return  render_template("predict_result.html", predict=predict[0], accuracy=accuracy, algorithm=algorithm_name)











app.run(host='0.0.0.0' , port=4440 , debug=True)